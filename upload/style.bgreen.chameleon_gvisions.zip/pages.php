<div class="content">
<?=$text?>