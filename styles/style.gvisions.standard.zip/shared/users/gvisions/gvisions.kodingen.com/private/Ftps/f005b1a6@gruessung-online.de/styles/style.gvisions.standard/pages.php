<div class="content"><p>
<?=$text?>
