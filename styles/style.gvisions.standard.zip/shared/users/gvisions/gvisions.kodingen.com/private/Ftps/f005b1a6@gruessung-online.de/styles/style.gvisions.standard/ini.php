<?php
$tpl['name']="Glass";
$tpl['version']="Release";
$tpl['menu']="0"; # 1 = vertical, 0 = horizontal
$tpl['menumore']="0"; #0 = nur ein Menu, #1 = mehrere
define('tpl_name',$tpl['name']);
define('tpl_version',$tpl['version']);
define('tpl_menu',$tpl['menu']);
define('tpl_menumore',$tpl['menumore']);

