</p></div>
<!--
Aufgrund von Perfomrmancegruenden wird der Bannerframe zu allerletzt geladen!
Damit erreichen wir, das die HP auch vor Laden des Banners benutzbar ist!
-->
<!-- BANNERFRAME -->
<div class="bannerframe">
<?=$banner?>
<br />Werbung</div>
<!-- BANNERFRAME -->
</body>
</html>